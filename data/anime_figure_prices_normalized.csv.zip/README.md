# Anime Figure Price Dataset

Japanese anime figure price data normalized across multiple sources.

- 655 records from MyFigureList
- Price comparisons across multiple Japanese hobby shops
- Updated weekly

For full dataset: https://atushi5.gumroad.com/l/agyhq